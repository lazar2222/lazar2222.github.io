#include <stdlib.h>
#include <time.h>
#include <stdio.h>
#include "Maxfiles.h"
#include <MaxSLiCInterface.h>

void generateTest(int* x, int* y)
{
	*x = rand() % 51 + 50;
	*y = rand() % 51 + 150;
}

int verify(int ec, int ac)
{
	return ec == ac;
}

int comp(const void* elem1, const void* elem2)
{
	int f = *((int*)elem1);
	int s = *((int*)elem2);
	if (f > s) return  1;
	if (f < s) return -1;
	return 0;
}

void swImpl(int n, int* kx, int* ky, int* kc, int x, int y, int* c)
{
	int* dist = calloc(n * 2, sizeof(int));

	for (int i = 0; i < n; i++)
	{
		dist[i * 2] = (kx[i] - x) * (kx[i] - x) + (ky[i] - y) * (ky[i] - y);
		dist[i * 2 + 1] = kc[i];
	}
	qsort(dist, n, sizeof(int) * 2, comp);
	int c0 = 0, c1 = 0;
	for (int i = 0; i < 5; i++)
	{
		c0 += dist[i * 2 + 1] == 0 ? 1 : 0;
		c1 += dist[i * 2 + 1] == 1 ? 1 : 0;
		//printf("%d\t",dist[i*2]);
	}
	//printf("\n");

	*c = c0 > c1 ? 0 : 1;

	free(dist);
}

int main()
{
	int n = 8;
	int kx[8] = { 51,  62, 69, 64, 65, 56, 58, 57 };
	int ky[8] = { 167, 182, 176, 173, 172, 174, 169, 173 };
	int kc[8] = { 0, 1, 1, 1, 1, 0, 1, 1 };
	int xs[2] = { 57, 66 };
	int ys[2] = { 170, 182 };
	int cs[2] = { 1,1 };
	int hwcs[8];

	printf("running canned tests\r\n");

	for (int i = 0; i < 2; i++)
	{
		int sw, hw;

		printf("running sw\r\n");
		swImpl(n, kx, ky, kc, xs[i], ys[i], &sw);

		printf("running hw\r\n");
		MovingAverage(n, xs[i], ys[i], kc, kx, ky, hwcs);
		hw = hwcs[7];

		int cmp = verify(cs[i], sw);
		printf("verifying software %s\r\n", cmp ? "PASS" : "FAIL");

		cmp = verify(cs[i], hw);
		printf("verifying hardware %s\r\n", cmp ? "PASS" : "FAIL");
	}

	printf("running generated tests\r\n");

	for (int i = 0; i < 10; i++)
	{
		int sw, hw;
		int x, y;

		generateTest(&x, &y);

		printf("running sw\r\n");
		swImpl(n, kx, ky, kc, x, y, &sw);

		printf("running hw\r\n");
		MovingAverage(n, x, y, kc, kx, ky, hwcs);
		hw = hwcs[7];

		int cmp = verify(sw, hw);
		printf("comparing software and hardware %s\r\n", cmp ? "PASS" : "FAIL");
	}

	return 0;
}