#include <stdlib.h>
#include <stdio.h>
#include "Maxfiles.h"
#include <MaxSLiCInterface.h>

void loadImage(const char* fname, int* w, int* h, unsigned char** data) 
{
    FILE* f = fopen(fname, "rb");
    fread(w, sizeof(int), 1, f);
    fread(h, sizeof(int), 1, f);
    *data = (unsigned char*)malloc(*w * *h * sizeof(unsigned char));
    fread(*data, sizeof(unsigned char), *w * *h, f);
    fclose(f);
}

void saveImage(const char* fname, int* w, int* h, unsigned char** data) 
{
    FILE* f = fopen(fname, "wb");
    fwrite(w, sizeof(int), 1, f);
    fwrite(h, sizeof(int), 1, f);
    fwrite(*data, sizeof(unsigned char), *w * *h, f);
    fclose(f);
}

int verify(unsigned char* reference, unsigned char* target, int size)
{
    int res = 0;
    for (int i = 0; i < size; i++)
    {
        res += reference[i] != target[i];
    }

    return res;
}

void swImpl(int w, int h, unsigned char* in, unsigned char* out)
{
    //Ovo daje identican rezultat kao originalni kod iz knjige
    float c = 0.1;

    for (int m = 0; m < h; m++)
    {
        float leg = 0;
        for (int n = 0; n < w; n++)
        {
            float t = in[m * w + n] + c * leg;

            if (t > 128)
            {
                leg = t - 128 * 2;
                out[m * w + n] = 255;
            }
            else {
                leg = t;
                out[m * w + n] = 0;
            }
        }
    }
}

int main()
{
    int w, h;
    unsigned char* data;
    unsigned char* sw;
    unsigned char* hw;

    loadImage("lena.bin", &w, &h, &data);
    sw = (unsigned char*)malloc(w * h * sizeof(unsigned char));
    hw = (unsigned char*)malloc(w * h * sizeof(unsigned char));

    printf("running sw\r\n");
    swImpl(w, h, data, sw);

    printf("running hw\r\n");
    SobelSolution(w, h, data, hw);

    int cmp = verify(sw, hw, w * h);
    saveImage("lena.out", &w, &h, &hw);

    printf("comparing resulting images %s\r\n", cmp == 0 ? "PASS" : "FAIL");

    free(data);
    free(sw);
    free(hw);

    //system("py imshow.py lena.bin");

    return 0;
}