#include <stdlib.h>
#include <time.h>
#include <stdio.h>
#include "Maxfiles.h"
#include <MaxSLiCInterface.h>

unsigned int rand32() 
{
	return rand() * RAND_MAX + rand();
}

void generateTest(int* n, float* a, float* b, float** x, float** y)
{
	//Pick a number of points in range [10, 100]
	*n = (rand32() % 91) + 10;
	*n /= 4;
	*n *= 4;
	//Pick line coefficients in range [-100, 100] with three decimal digits;
	*a = ((rand32() % 200001) / 1000.0) - 100;
	*b = ((rand32() % 200001) / 1000.0) - 100;

	//Allocate memory for points
	*x = calloc(*n, sizeof(float));
	*y = calloc(*n, sizeof(float));

	//Generate n points on x axis in range [-100, 100] with three decimal digits;
	for (int i = 0; i < *n; i++)
	{
		(*x)[i] = ((rand32() % 200001) / 1000.0) - 100;
		//Calculate y at that point
		(*y)[i] = *a * (*x)[i] + *b;
		//Pick a random fudge factor in range [0.9, 1.1] with three decimal digits;
		float fudge = ((rand32() % 201) / 1000.0) + 0.9;
		//Modify y by that factor
		(*y)[i] = (*y)[i] * fudge;
	}
}

void cleanupTest(float** x, float** y) 
{
	free(*x);
	free(*y);
}

int verify(float exA, float exB, float actA, float actB) 
{
	float mfA = actA / exA;
	float mfB = actB / exB;
	return 0.81 <= mfA && mfA <= 1.21 && 0.81 <= mfB && mfB <= 1.21;
}

int compare(float swA, float swB, float hwA, float hwB) 
{
	float diffA = swA > hwA ? swA - hwA : hwA - swA;
	float diffB = swB > hwB ? swB - hwB : hwB - swB;
	return diffA < 0.001 && diffB < 0.001;
}

void swImpl(int n, float* x, float* y, float* a, float* b) 
{
	float sX = 0;
	float sY = 0;
	float sXY = 0;
	float sXX = 0;

	for (int i = 0; i < n; i++)
	{
		sX += x[i];
		sY += y[i];
		sXY += x[i] * y[i];
		sXX += x[i] * x[i];
	}

	float denom = n * sXX - sX * sX;

	*a = (n * sXY - sX * sY) / denom;
	*b = (sY * sXX - sX * sXY) / denom;
}

int main() 
{
	srand(time(NULL));

	int n;
	float a, b;
	float* x;
	float* y;
	generateTest(&n, &a, &b, &x, &y);

	printf("test: points %d, a %f b %f\r\n", n, a, b);
	/*for (int i = 0; i < n; i++)
	{
		printf("%f %f\r\n", x[i], y[i]);
	}*/

	printf("\r\n");

	printf("running sw\r\n");
	float swA, swB;
	swImpl(n, x, y, &swA, &swB);
	
	printf("running hw\r\n");
	float hwA, hwB;
	float* hwAA = calloc(n, sizeof(float));
	float* hwBA = calloc(n, sizeof(float));
	MovingAverage(n, x, y, hwAA, hwBA);
	
	hwA = hwAA[n-1];
	hwB = hwBA[n-1];
	
	free(hwAA);
	free(hwBA);

	//int verr = verify(a, b, swA, swB);
	int cmp = compare(swA, swB, hwA, hwB);

	//printf("verifying test exA %f exB %f actA %f actB %f %s\r\n", a, b, swA, swB, verr ? "PASS" : "FAIL");

	printf("comparing test swA %f swB %f hwA %f hwB %f %s\r\n", swA, swB, hwA, hwB, cmp ? "PASS" : "FAIL");

	cleanupTest(&x, &y);

	return 0;
}